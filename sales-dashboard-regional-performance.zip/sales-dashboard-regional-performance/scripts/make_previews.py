"""
Render preview charts of the three dashboard pages with matplotlib (from sales.db).
These are previews of the analysis - replace them with real Power BI screenshots
once you have built the .pbix (see powerbi/BUILD_GUIDE.md).

Run:  python scripts/make_previews.py
"""
import os
import sqlite3
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.join(os.path.dirname(__file__), "..")
OUT = os.path.join(ROOT, "images")
os.makedirs(OUT, exist_ok=True)

con = sqlite3.connect(os.path.join(ROOT, "sales.db"))
d = pd.read_sql("SELECT * FROM vw_sales_detail", con)
d["month"] = pd.to_datetime(d["year_month"] + "-01")

# one fixed colour per region (colour follows the entity, not its rank)
REGION_COLOR = {"North": "#2a78d6", "South": "#eb6834", "East": "#1baf7a", "West": "#eda100", "Central": "#e87ba4"}
INK, MUTED, GRID, BG = "#0b0b0b", "#52514e", "#e6e5e1", "#fcfcfb"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "axes.facecolor": BG, "figure.facecolor": BG,
    "axes.edgecolor": GRID, "axes.labelcolor": MUTED, "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
})

def lakh(x, _=None):
    return f"{x/1e5:.0f}L"

def crore(x):
    return f"₹{x/1e7:.2f} Cr"

# ---------------- Page 1: Executive overview ----------------
fig = plt.figure(figsize=(13, 7.2))
fig.suptitle("Page 1 · Executive Overview — Sales Dashboard for Regional Performance (2025)",
             x=0.02, ha="left", fontsize=14, fontweight="bold", color=INK)
kpis = [
    ("Total revenue", crore(d.revenue.sum())),
    ("Total profit", crore(d.profit.sum())),
    ("Profit margin", f"{100*d.profit.sum()/d.revenue.sum():.1f}%"),
    ("Order lines", f"{len(d):,}"),
    ("Avg order value", f"₹{d.revenue.mean():,.0f}"),
]
for i, (k, v) in enumerate(kpis):
    ax = fig.add_axes([0.02 + i * 0.196, 0.80, 0.18, 0.11]); ax.axis("off")
    ax.add_patch(plt.Rectangle((0, 0), 1, 1, fill=False, ec=GRID, lw=1.2, transform=ax.transAxes))
    ax.text(0.06, 0.64, k, fontsize=10, color=MUTED, transform=ax.transAxes)
    ax.text(0.06, 0.18, v, fontsize=17, fontweight="bold", color=INK, transform=ax.transAxes)

ax1 = fig.add_axes([0.06, 0.10, 0.50, 0.60])
by_region = d.groupby("region").revenue.sum().sort_values()
bars = ax1.barh(by_region.index, by_region.values, color=[REGION_COLOR[r] for r in by_region.index], height=0.6)
for b, v in zip(bars, by_region.values):
    ax1.text(v + by_region.max() * 0.01, b.get_y() + b.get_height() / 2, crore(v), va="center", fontsize=10, color=INK)
ax1.set_title("Revenue by region", loc="left", fontsize=11, color=INK, fontweight="bold")
ax1.xaxis.set_visible(False); ax1.grid(False); ax1.set_xlim(0, by_region.max() * 1.18)

ax2 = fig.add_axes([0.64, 0.10, 0.33, 0.60])
by_cat = d.groupby("category").revenue.sum().sort_values()
bars = ax2.barh(by_cat.index, by_cat.values, color="#2a78d6", height=0.6)
for b, v in zip(bars, by_cat.values):
    ax2.text(v + by_cat.max() * 0.01, b.get_y() + b.get_height() / 2, crore(v), va="center", fontsize=9.5, color=INK)
ax2.set_title("Revenue by product category", loc="left", fontsize=11, color=INK, fontweight="bold")
ax2.xaxis.set_visible(False); ax2.grid(False); ax2.set_xlim(0, by_cat.max() * 1.3)
fig.savefig(os.path.join(OUT, "page1_executive_overview.png"), dpi=140)
plt.close(fig)

# ---------------- Page 2: Regional trends ----------------
m = d.groupby(["month", "region"]).revenue.sum().unstack()
fig, ax = plt.subplots(figsize=(13, 6.4))
fig.subplots_adjust(left=0.07, right=0.88, top=0.86, bottom=0.10)
fig.suptitle("Page 2 · Regional Trends — monthly revenue by region", x=0.02, ha="left", fontsize=14,
             fontweight="bold", color=INK)
for r in m.columns:
    ax.plot(m.index, m[r], color=REGION_COLOR[r], lw=2.4 if r == "South" else 1.8, marker="o", ms=4)
    ax.text(m.index[-1] + pd.Timedelta(days=8), m[r].iloc[-1], r, color=INK, va="center", fontsize=10)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lakh)); ax.set_ylabel("Revenue (₹ lakh)")
ax.axvspan(pd.Timestamp("2025-10-01"), pd.Timestamp("2025-10-31"), color="#eb6834", alpha=0.08, lw=0)
ax.text(pd.Timestamp("2025-10-16"), ax.get_ylim()[1] * 0.99, "Festival\nmonth", ha="center", va="top", fontsize=9, color=MUTED)
ax.set_xticks(m.index); ax.set_xticklabels([x.strftime("%b") for x in m.index])
fig.savefig(os.path.join(OUT, "page2_regional_trends.png"), dpi=140)
plt.close(fig)

# ---------------- Page 3: Post-festival insight ----------------
fig = plt.figure(figsize=(13, 6.6))
fig.suptitle("Page 3 · Post-Festival Analysis — South region fell the hardest after the festival peak",
             x=0.02, ha="left", fontsize=14, fontweight="bold", color=INK)
ax = fig.add_axes([0.07, 0.10, 0.40, 0.72])
chg = ((m.loc["2025-11-01"] / m.loc["2025-10-01"] - 1) * 100).sort_values()
bars = ax.barh(chg.index, chg.values, color=[REGION_COLOR[r] for r in chg.index], height=0.6)
for b, v in zip(bars, chg.values):
    ax.text(v - 0.3, b.get_y() + b.get_height() / 2, f"{v:.1f}%", va="center", ha="right", fontsize=10.5,
            color=INK, fontweight="bold" if v < -10 else "normal")
ax.set_xlim(chg.min() * 1.25, 0); ax.xaxis.set_visible(False); ax.grid(False)
ax.set_title("Revenue change, Oct (festival) → Nov, by region", loc="left", fontsize=11, color=INK, fontweight="bold")

ax = fig.add_axes([0.58, 0.10, 0.39, 0.72])
s = d[(d.region == "South") & (d.year_month.isin(["2025-10", "2025-11"]))]
cat = s.pivot_table(index="category", columns="year_month", values="revenue", aggfunc="sum")
cat["chg"] = (cat["2025-11"] / cat["2025-10"] - 1) * 100
cat = cat.sort_values("chg")
bars = ax.barh(cat.index, cat["chg"], color="#eb6834", height=0.6)
for b, v in zip(bars, cat["chg"]):
    ax.text(v + (1 if v >= 0 else -1), b.get_y() + b.get_height() / 2, f"{v:+.1f}%", va="center",
            ha="left" if v >= 0 else "right", fontsize=10, color=INK)
ax.axvline(0, color=MUTED, lw=1); ax.grid(False); ax.xaxis.set_visible(False)
ax.set_xlim(-70, 65)
ax.set_title("South: Oct → Nov change by category", loc="left", fontsize=11, color=INK, fontweight="bold")
fig.savefig(os.path.join(OUT, "page3_post_festival_insight.png"), dpi=140)
plt.close(fig)
print("Saved previews to", os.path.abspath(OUT))
