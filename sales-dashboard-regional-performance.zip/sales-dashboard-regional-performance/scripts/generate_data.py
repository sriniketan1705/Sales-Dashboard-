"""
Generate a synthetic sales dataset for the Regional Sales Dashboard project.

Output (data/):
  customers.csv  - 1,200 customers across 5 regions
  products.csv   - 40 products across 5 categories
  sales.csv      - ~26,000 order lines across 12 months (Jan-Dec 2025)

The data is SYNTHETIC. It is designed so that the South region has a strong
festival (Diwali) peak in October 2025 followed by a ~14% revenue drop in
November 2025, which is the insight the dashboard surfaces.

Run:  python scripts/generate_data.py
"""
import os
import numpy as np
import pandas as pd

SEED = 2025
rng = np.random.default_rng(SEED)

OUT = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(OUT, exist_ok=True)

REGIONS = {
    "North":   ["Delhi", "Chandigarh", "Lucknow", "Jaipur"],
    "South":   ["Chennai", "Bengaluru", "Hyderabad", "Kochi"],
    "East":    ["Kolkata", "Bhubaneswar", "Patna", "Guwahati"],
    "West":    ["Mumbai", "Pune", "Ahmedabad", "Surat"],
    "Central": ["Bhopal", "Indore", "Nagpur", "Raipur"],
}
REGION_WEIGHT = {"North": 0.22, "South": 0.26, "East": 0.16, "West": 0.24, "Central": 0.12}
SEGMENTS = ["Consumer", "Corporate", "Small Business"]

# ---------- customers ----------
N_CUST = 1200
cust_regions = rng.choice(list(REGIONS), size=N_CUST, p=list(REGION_WEIGHT.values()))
customers = pd.DataFrame({
    "customer_id": np.arange(1, N_CUST + 1),
    "customer_name": [f"Customer {i:04d}" for i in range(1, N_CUST + 1)],
    "segment": rng.choice(SEGMENTS, size=N_CUST, p=[0.55, 0.25, 0.20]),
    "region": cust_regions,
})
customers["city"] = [rng.choice(REGIONS[r]) for r in customers["region"]]

# ---------- products ----------
CATALOG = {
    "Electronics":  [("Smartphone", 18000), ("Earbuds", 2500), ("Smart Watch", 6500), ("Bluetooth Speaker", 3200),
                     ("Power Bank", 1800), ("Tablet", 22000), ("Laptop Sleeve", 900), ("Webcam", 2700)],
    "Home & Kitchen": [("Mixer Grinder", 4200), ("Air Fryer", 7500), ("Induction Cooktop", 3800), ("Water Purifier", 11000),
                       ("Pressure Cooker", 2200), ("Dinner Set", 3100), ("Vacuum Cleaner", 8800), ("Iron Box", 1500)],
    "Fashion":      [("Silk Saree", 6000), ("Kurta Set", 2400), ("Men's Shirt", 1600), ("Sports Shoes", 3500),
                     ("Handbag", 2800), ("Jeans", 2100), ("Ethnic Jacket", 3900), ("Sunglasses", 1900)],
    "Grocery & Gifting": [("Dry Fruit Box", 1400), ("Sweets Gift Box", 900), ("Premium Tea", 650), ("Cold-pressed Oil", 780),
                          ("Organic Honey", 520), ("Festival Hamper", 2600), ("Coffee Beans", 700), ("Spice Kit", 450)],
    "Furniture":    [("Office Chair", 7800), ("Study Table", 6400), ("Bookshelf", 5200), ("Sofa Set", 32000),
                     ("Bed Frame", 18500), ("Wardrobe", 21000), ("Shoe Rack", 2300), ("Coffee Table", 4600)],
}
rows = []
pid = 1
for cat, items in CATALOG.items():
    for name, price in items:
        rows.append((pid, name, cat, price, round(price * rng.uniform(0.55, 0.75), 2)))
        pid += 1
products = pd.DataFrame(rows, columns=["product_id", "product_name", "category", "unit_price", "unit_cost"])

# ---------- sales ----------
# Base number of order lines per region/month. Festival season (Oct) peaks,
# South peaks hardest and drops sharply in Nov (post-festival slump).
BASE_LINES_PER_MONTH = 2000
month_idx = {
    "North":   [0.92, 0.88, 0.95, 0.98, 1.00, 0.96, 0.97, 1.02, 1.05, 1.28, 1.20, 1.10],
    "South":   [0.90, 0.86, 0.93, 0.97, 1.00, 0.95, 0.96, 1.01, 1.06, 1.40, 1.18, 1.08],
    "East":    [0.90, 0.87, 0.94, 0.97, 0.99, 0.95, 0.96, 1.00, 1.04, 1.22, 1.17, 1.07],
    "West":    [0.93, 0.90, 0.96, 1.00, 1.02, 0.97, 0.98, 1.03, 1.06, 1.30, 1.22, 1.12],
    "Central": [0.91, 0.88, 0.94, 0.97, 0.99, 0.95, 0.96, 1.00, 1.03, 1.20, 1.15, 1.06],
}
# Post-festival: November revenue as a fraction of October revenue per region.
# South falls hardest (-14%); other regions dip only slightly.
NOV_TARGET = {"South": 0.8595, "North": 0.96, "East": 0.95, "West": 0.96, "Central": 0.95}

# Category affinity by month (festival boosts Fashion / Gifting / Electronics in Oct)
def cat_probs(month, region):
    p = {"Electronics": 0.27, "Home & Kitchen": 0.22, "Fashion": 0.22, "Grocery & Gifting": 0.17, "Furniture": 0.12}
    if month == 10:
        p.update({"Fashion": 0.27, "Grocery & Gifting": 0.22, "Electronics": 0.28, "Home & Kitchen": 0.14, "Furniture": 0.09})
    s = sum(p.values())
    return {k: v / s for k, v in p.items()}

cust_by_region = {r: customers.loc[customers.region == r, "customer_id"].to_numpy() for r in REGIONS}
prod_by_cat = {c: products.loc[products.category == c, "product_id"].to_numpy() for c in CATALOG}
price = products.set_index("product_id")["unit_price"].to_dict()
cost = products.set_index("product_id")["unit_cost"].to_dict()

frames = []
for region, w in REGION_WEIGHT.items():
    for m in range(1, 13):
        n = int(BASE_LINES_PER_MONTH * w * month_idx[region][m - 1])
        pool = int(n * 1.6) if m == 11 else n  # November: oversample, then trim to target
        cp = cat_probs(m, region)
        cats = rng.choice(list(cp), size=pool, p=list(cp.values()))
        pids = np.array([rng.choice(prod_by_cat[c]) for c in cats])
        days_in = pd.Period(f"2025-{m:02d}").days_in_month
        dates = pd.to_datetime(f"2025-{m:02d}-01") + pd.to_timedelta(rng.integers(0, days_in, size=pool), unit="D")
        qty = rng.choice([1, 2, 3, 4], size=pool, p=[0.62, 0.24, 0.10, 0.04])
        disc = rng.choice([0, 0.05, 0.10, 0.15], size=pool, p=[0.50, 0.25, 0.17, 0.08])
        if m == 10:  # festival discounts
            disc = rng.choice([0, 0.05, 0.10, 0.15, 0.20], size=pool, p=[0.20, 0.20, 0.25, 0.20, 0.15])
        df = pd.DataFrame({
            "order_date": dates, "customer_id": rng.choice(cust_by_region[region], size=pool),
            "product_id": pids, "quantity": qty, "discount": disc,
        })
        rev = np.array([price[p] * q * (1 - d) for p, q, d in zip(df.product_id, df.quantity, df.discount)])
        if m == 10:
            oct_rev = rev.sum()
        if m == 11:
            k = int(np.argmin(np.abs(np.cumsum(rev) - NOV_TARGET[region] * oct_rev))) + 1
            df = df.iloc[:k]
        frames.append(df)

sales = pd.concat(frames, ignore_index=True).sort_values("order_date").reset_index(drop=True)
sales.insert(0, "sale_id", np.arange(1, len(sales) + 1))
sales["order_date"] = sales["order_date"].dt.strftime("%Y-%m-%d")
sales["revenue"] = [round(price[p] * q * (1 - d), 2) for p, q, d in zip(sales.product_id, sales.quantity, sales.discount)]
sales["cost"] = [round(cost[p] * q, 2) for p, q in zip(sales.product_id, sales.quantity)]

customers.to_csv(os.path.join(OUT, "customers.csv"), index=False)
products.to_csv(os.path.join(OUT, "products.csv"), index=False)
sales.to_csv(os.path.join(OUT, "sales.csv"), index=False)

total = len(customers) + len(products) + len(sales)
print(f"customers={len(customers)} products={len(products)} sales={len(sales)} total_records={total}")
