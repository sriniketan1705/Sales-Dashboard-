"""
Build a ready-to-query SQLite database (sales.db) from the SQL scripts + CSVs.

Run:  python scripts/load_sqlite.py
Then: sqlite3 sales.db < sql/03_analysis_queries.sql   (or use DB Browser for SQLite)
"""
import os
import sqlite3
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
DB = os.path.join(ROOT, "sales.db")

if os.path.exists(DB):
    os.remove(DB)

con = sqlite3.connect(DB)
for script in ("01_schema.sql", "02_views.sql"):
    # views need the tables first, so load data between the two scripts
    if script == "02_views.sql":
        for t in ("customers", "products", "sales"):
            pd.read_csv(os.path.join(ROOT, "data", f"{t}.csv")).to_sql(t, con, if_exists="append", index=False)
    with open(os.path.join(ROOT, "sql", script)) as f:
        con.executescript(f.read())
con.commit()

for t in ("customers", "products", "sales"):
    print(t, con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0])
con.close()
print("Created", os.path.abspath(DB))
