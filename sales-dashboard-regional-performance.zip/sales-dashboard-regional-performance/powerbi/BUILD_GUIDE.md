# Power BI Build Guide

A `.pbix` file can only be created in Power BI Desktop (Windows), so this guide walks you through
building the dashboard from the SQL views and DAX measures in this repo. It takes about 45-60 minutes.
Save the result as `powerbi/Sales_Dashboard_Regional_Performance.pbix` and add screenshots to `images/`.

## 1. Connect the data

**Option A - CSV (easiest):** Get Data > Text/CSV > load `data/customers.csv`, `data/products.csv`, `data/sales.csv`.
In Model view create relationships (many-to-one, single direction):
`sales[customer_id] -> customers[customer_id]`, `sales[product_id] -> products[product_id]`.

**Option B - SQL database (matches the resume wording):** load the CSVs into MySQL / SQL Server / PostgreSQL
using `sql/01_schema.sql` and `sql/02_views.sql` (adjust the month expression as noted in the file),
then Get Data > SQL Server (or MySQL / PostgreSQL) and import the view `vw_sales_detail`.

> If you use Option A, create the flat table in Power Query: merge `sales` with `customers` and `products`,
> or build `vw_sales_detail` as a SQL view and import that. Measures in `dax_measures.dax` assume the
> flat table is named `vw_sales_detail`.

## 2. Model

1. Add the `Calendar` table from `dax_measures.dax`, mark it as the date table, relate it to `order_date`.
2. Create a `_Measures` table and paste in the measures.
3. View > Themes > Browse for themes > import `powerbi/theme.json`.
4. Format `region` colours: South = orange, North = blue, East = green, West = yellow, Central = pink
   (keep each region on the same colour across every page).

## 3. Pages

### Page 1 - Executive Overview
| Visual | Fields |
|---|---|
| 5 KPI cards | Total Revenue, Total Profit, Profit Margin %, Order Lines, Avg Order Value |
| Bar chart | Axis: region, Values: Total Revenue (sorted desc, data labels on) |
| Bar chart | Axis: category, Values: Total Revenue |
| Slicers | Calendar[Month], region, category, segment |

### Page 2 - Regional Trends
| Visual | Fields |
|---|---|
| Line chart | X: Calendar[Year-Month], Y: Total Revenue, Legend: region |
| Clustered column | X: region, Y: Total Revenue, Legend: category |
| Matrix | Rows: region, Columns: Calendar[Month], Values: Total Revenue (conditional-format background) |
| Slicers | region, category, date range |

### Page 3 - Post-Festival Analysis (the key insight)
| Visual | Fields |
|---|---|
| Bar chart | Axis: region, Value: Post-Festival Change % (South should be about -13.6%) |
| Bar chart | Filter region = South. Axis: category, Value: Post-Festival Change % |
| Cards | Festival Month Revenue, Post-Festival Revenue (filtered to South) |
| Text box | Recommendation: targeted marketing recovery plan for South (see README) |

Turn on **Edit interactions** so clicking a region cross-filters every visual, and add a
**Drillthrough** page from region > category.

## 4. Publish to GitHub

1. Export screenshots: File > Export > PDF, or screenshot each page, into `images/`.
2. Save the `.pbix` inside `powerbi/` (it is small enough for GitHub; otherwise use Git LFS).
3. Update the README "Dashboard screenshots" section to point at your real screenshots.
