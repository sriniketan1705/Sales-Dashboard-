-- =====================================================================
-- Views consumed by Power BI
-- (SQLite syntax shown: substr() for the month key. On SQL Server use
--  FORMAT(order_date,'yyyy-MM'); on MySQL DATE_FORMAT(order_date,'%Y-%m');
--  on PostgreSQL TO_CHAR(order_date,'YYYY-MM').)
-- =====================================================================

-- Flat 3-table join: one row per order line, ready for Power BI import
CREATE VIEW vw_sales_detail AS
SELECT
    s.sale_id,
    s.order_date,
    substr(s.order_date, 1, 7)           AS year_month,
    c.customer_id,
    c.segment,
    c.region,
    c.city,
    p.product_id,
    p.product_name,
    p.category,
    s.quantity,
    s.discount,
    s.revenue,
    s.cost,
    (s.revenue - s.cost)                 AS profit
FROM sales      s
JOIN customers  c ON c.customer_id = s.customer_id
JOIN products   p ON p.product_id  = s.product_id;

-- Pre-aggregated month x region table (fast trend visuals)
CREATE VIEW vw_monthly_region_sales AS
SELECT
    year_month,
    region,
    COUNT(*)                 AS order_lines,
    SUM(quantity)            AS units_sold,
    ROUND(SUM(revenue), 2)   AS revenue,
    ROUND(SUM(profit), 2)    AS profit
FROM vw_sales_detail
GROUP BY year_month, region;
