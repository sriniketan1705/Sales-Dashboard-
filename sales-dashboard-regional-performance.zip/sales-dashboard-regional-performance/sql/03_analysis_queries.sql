-- =====================================================================
-- Analysis queries behind the dashboard pages
-- =====================================================================

-- Q1. Regional performance summary --------------------------------------
SELECT region,
       COUNT(*)                                   AS order_lines,
       ROUND(SUM(revenue), 0)                     AS revenue,
       ROUND(SUM(profit), 0)                      AS profit,
       ROUND(100.0 * SUM(profit) / SUM(revenue), 1) AS profit_margin_pct,
       ROUND(AVG(revenue), 0)                     AS avg_order_value
FROM vw_sales_detail
GROUP BY region
ORDER BY revenue DESC;

-- Q2. Monthly revenue trend by region -----------------------------------
SELECT year_month, region, revenue
FROM vw_monthly_region_sales
ORDER BY year_month, region;

-- Q3. Category performance per region ------------------------------------
SELECT region, category,
       ROUND(SUM(revenue), 0) AS revenue,
       ROUND(100.0 * SUM(revenue) /
             SUM(SUM(revenue)) OVER (PARTITION BY region), 1) AS share_of_region_pct
FROM vw_sales_detail
GROUP BY region, category
ORDER BY region, revenue DESC;

-- Q4. Month-over-month growth per region (window function) --------------
SELECT region, year_month, revenue,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (PARTITION BY region ORDER BY year_month))
             / LAG(revenue) OVER (PARTITION BY region ORDER BY year_month), 1) AS mom_growth_pct
FROM vw_monthly_region_sales
ORDER BY region, year_month;

-- Q5. KEY INSIGHT: post-festival (Oct -> Nov) decline by region ----------
-- October = festival (Diwali) month, November = post-festival month.
WITH festival AS (
    SELECT region,
           SUM(CASE WHEN year_month = '2025-10' THEN revenue END) AS oct_revenue,
           SUM(CASE WHEN year_month = '2025-11' THEN revenue END) AS nov_revenue
    FROM vw_sales_detail
    GROUP BY region
)
SELECT region,
       ROUND(oct_revenue, 0) AS festival_month_revenue,
       ROUND(nov_revenue, 0) AS post_festival_revenue,
       ROUND(100.0 * (nov_revenue - oct_revenue) / oct_revenue, 1) AS change_pct
FROM festival
ORDER BY change_pct;

-- Q6. Where did South lose revenue? Category drill-down (Oct vs Nov) -----
SELECT category,
       ROUND(SUM(CASE WHEN year_month = '2025-10' THEN revenue END), 0) AS oct_revenue,
       ROUND(SUM(CASE WHEN year_month = '2025-11' THEN revenue END), 0) AS nov_revenue,
       ROUND(100.0 * (SUM(CASE WHEN year_month = '2025-11' THEN revenue END)
                    - SUM(CASE WHEN year_month = '2025-10' THEN revenue END))
             / SUM(CASE WHEN year_month = '2025-10' THEN revenue END), 1) AS change_pct
FROM vw_sales_detail
WHERE region = 'South'
GROUP BY category
ORDER BY change_pct;

-- Q7. Top 10 products by revenue ----------------------------------------
SELECT product_name, category, ROUND(SUM(revenue), 0) AS revenue, SUM(quantity) AS units
FROM vw_sales_detail
GROUP BY product_name, category
ORDER BY revenue DESC
LIMIT 10;
