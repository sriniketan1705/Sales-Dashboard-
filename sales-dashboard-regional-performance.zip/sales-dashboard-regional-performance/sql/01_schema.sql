-- =====================================================================
-- Regional Sales Dashboard : schema
-- Dialect: standard SQL (tested on SQLite; works on MySQL / PostgreSQL /
-- SQL Server with minor type changes noted in comments).
-- =====================================================================

DROP VIEW  IF EXISTS vw_sales_detail;
DROP VIEW  IF EXISTS vw_monthly_region_sales;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

-- Table 1: customers (dimension) -------------------------------------
CREATE TABLE customers (
    customer_id    INTEGER      PRIMARY KEY,
    customer_name  VARCHAR(60)  NOT NULL,
    segment        VARCHAR(30)  NOT NULL,   -- Consumer / Corporate / Small Business
    region         VARCHAR(20)  NOT NULL,   -- North / South / East / West / Central
    city           VARCHAR(40)  NOT NULL
);

-- Table 2: products (dimension) --------------------------------------
CREATE TABLE products (
    product_id     INTEGER       PRIMARY KEY,
    product_name   VARCHAR(60)   NOT NULL,
    category       VARCHAR(40)   NOT NULL,
    unit_price     DECIMAL(10,2) NOT NULL,
    unit_cost      DECIMAL(10,2) NOT NULL
);

-- Table 3: sales (fact) ----------------------------------------------
CREATE TABLE sales (
    sale_id        INTEGER       PRIMARY KEY,
    order_date     DATE          NOT NULL,
    customer_id    INTEGER       NOT NULL REFERENCES customers(customer_id),
    product_id     INTEGER       NOT NULL REFERENCES products(product_id),
    quantity       INTEGER       NOT NULL,
    discount       DECIMAL(4,2)  NOT NULL,   -- 0.10 = 10% off
    revenue        DECIMAL(12,2) NOT NULL,   -- unit_price * quantity * (1 - discount)
    cost           DECIMAL(12,2) NOT NULL
);

-- Indexes that support the join + filter pattern used by the dashboard
CREATE INDEX idx_sales_date     ON sales(order_date);
CREATE INDEX idx_sales_customer ON sales(customer_id);
CREATE INDEX idx_sales_product  ON sales(product_id);
CREATE INDEX idx_customers_region ON customers(region);
